Installing the GRBL_laser.cbpp cambam config file:

This file lives in different locations depending on your operating system.  Simply extract the zip file to the directory suggested.  The post processor is stored in a zip file due to the way browsers handle xml.

After installing the post processor, restart Cambam.

Windows 7:
C:\ProgramData\CamBam plus 0.9.8\post

Linux (Ubuntu)
~/.config/CamBam plus 0.9.8/post
